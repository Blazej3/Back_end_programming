package exercise.bookstore.domain;

public class Private {

}
