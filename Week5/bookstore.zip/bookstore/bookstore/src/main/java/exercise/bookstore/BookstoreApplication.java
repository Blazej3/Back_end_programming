package exercise.bookstore;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import exercise.bookstore.domain.Book;
import exercise.bookstore.domain.Bookrepository;
import exercise.bookstore.domain.Category;
import exercise.bookstore.domain.Categoryrepository;

@SpringBootApplication
public class BookstoreApplication {
	private static final Logger log = LoggerFactory.getLogger(BookstoreApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApplication.class, args);
	}



	@Bean
	public CommandLineRunner bookDemo(Bookrepository repository, Categoryrepository c_repository) {
		return (args) -> {
			log.info("save a couple of books");

Category category1 = new Category("a");
Category category2 = new Category("b");
Category category3 = new Category("c");

c_repository.save(category1);
c_repository.save(category2);
c_repository.save(category3);

			repository.save(new Book("The Great Gatsby", "F. Scott Fitzgerald", 1925, "9780743273565", 10.99, category1));
			repository.save(new Book("To Kill a Mockingbird", "Harper Lee", 1960, "9780061120084", 12.99, category3));	
			
			log.info("fetch all books");
			for (Book book : repository.findAll()) {
				log.info(book.toString());
			}

		};
	}
}
